#pragma once


#include <iostream>
#include <fstream>

#include "MyList.h"

void SearchHayStack(char* chrInBinaryFile, MyList* nsNeedle);